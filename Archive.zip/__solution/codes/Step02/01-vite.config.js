// vite.config.js - Step2 Task1
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import { viteStaticCopy } from 'vite-plugin-static-copy'
import path from 'path'

// https://vite.dev/config/
export default defineConfig({
  server: {
    port: 8080,
    host: true,
    allowedHosts: ['chidlike-xxxxx-i5yv--8080.pluralsight.run'],
  },
  preview: {
    port: 8080,
    host: true,
    allowedHosts: ['chidlike-xxxxx-i5yv--8080.pluralsight.run'],
  },
  plugins: [
    react(), 
    tailwindcss(),
    viteStaticCopy({
      targets: [
        {
          src: '__solution/images/*',
          dest: 'completed-steps'
        }
      ]
    })
  ],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, 'src'),
    },
  },
  test: {
    globals: true,
    environment: 'jsdom',
    setupFiles: './setupTests.js',
  }
})
