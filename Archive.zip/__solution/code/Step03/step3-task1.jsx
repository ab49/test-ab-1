// src/App.jsx
import AppPower from './components/AppPower';
import DevPanel from './components/DevPanel';
import Disclaimer from './components/Disclaimer';
import FoodieRating from './components/FoodieRating';
import Introduction from './components/Introduction';
import OnlineMenu from './components/OnlineMenu';
import Testimonials from './components/Testimonials';
import './App.css';

function App() {
  return (
    <div className="app-container min-h-screen flex flex-col items-center justify-center p-2">
      <div className="inner-section px-8 py-2 max-w-7xl mx-auto my-8">
        <Introduction />
        <div className="flex main-section">
          <div className="menu-section w-3/4 px-5 py-2">
            <OnlineMenu />
          </div>
          <div className="sidebar w-1/4 px-5 py-2">
            <DevPanel />
            <FoodieRating />
            <Testimonials />
          </div>
        </div>
        <Disclaimer />
        <AppPower />
      </div>
    </div>
  )
}

export default App;
