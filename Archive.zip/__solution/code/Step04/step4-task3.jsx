// src/components/DevPanel.jsx
import React from 'react';

const DevPanel = () => {
  
  // use built in constant to fix the variables below
  const isDev = import.meta.env.DEV;
  const mode = import.meta.env.MODE;
  const baseUrl = import.meta.env.BASE_URL;
  
  if(!isDev){
    return;
  }

  return (
    <section className="dev-panel background-light-red p-8 rounded-lg shadow-md max-w-md mx-auto my-8">
      <h2 className="text-2xl font-bold text-center text-red-700 mb-4 border-b pb-2">Dev Panel</h2>
      <p><b>Mode</b>: {mode}</p>
      <p>
        <b>Documentation</b>: 
         <a target="_blank" rel="noopener noreferrer" className="text-red-600 hover:text-red-800 underline"href={baseUrl + `documentation.txt`}>Click here</a>
      </p>
    </section>
  );
}

export default DevPanel;
