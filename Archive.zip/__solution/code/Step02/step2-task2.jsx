// src/components/Introduction.jsx
import introText from '../assets/data/intro.txt?raw';
import aboutUsUrl from '../assets/data/about-us.txt';

const Introduction = () => {
    
    return (
        <section className="introduction max-w-xl mx-auto">

            {/* Add pizzaLogo image url in the src attribute from the public directory */}
            <div className="flex justify-center">
                <img src={''} alt="Pizza Company Logo" className="company-logo w-20 mb-4" />
            </div>
            
            {/* Add h2 element with text `Welcome to Pizza shop` above the <p> element */}
            <h2>Welcome to the Pizza Shop.</h2>
            <p id="intro-para" className={` mb-4 text-center`} >{introText}</p>

            <p id="start-info" className="text-gray-600 mb-4 text-center">
                Serving people since: <span className="font-semibold">{'1990-02-21'}</span> by <span className="font-semibold">{'Mario Rossi'}</span>
            </p>

            <div className="text-center mb-4">
                <a 
                    href={aboutUsUrl} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-red-600 hover:text-red-800 underline"
                >
                    Read more about us
                </a>
            </div>
        </section>
    );
};

export default Introduction;
