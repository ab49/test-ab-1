// src/components/AppPower.jsx

const AppPower = () => {
    return (
        <p className="text-gray-700 text-center pt-5">
            Application Powered by: 
            <img src="/react.svg" alt="React Logo" className="react-logo inline w-8 h-8 ml-2 align-middle" />
        </p>
    );
};

export default AppPower;