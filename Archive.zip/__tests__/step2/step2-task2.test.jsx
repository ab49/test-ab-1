import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import '@testing-library/jest-dom'
import Introduction from '@/components/Introduction'

describe('add <h2> element to the Introduction Component', () => {
  it('ensure that you have added an h2 element above the paragraph element in the Introduction component (src/components/Introduction.jsx) with the text "Welcome to the Pizza Shop"', () => {
    
    const { container } = render(<Introduction />)
    
    const heading = screen.getByRole('heading', { level: 2, name: /Welcome to the Pizza Shop/i })    
    expect(heading).toBeInTheDocument()

    const paragraph = container.querySelector('p#intro-para')
    expect(paragraph).toBeInTheDocument()
    expect(heading.nextElementSibling).toBe(paragraph)
  })
})
