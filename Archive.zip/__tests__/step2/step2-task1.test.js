// @vitest-environment node
import { describe, it, expect } from "vitest";
import path from "path";

const configPath = path.resolve(process.cwd(), "vite.config.js");
const { default: viteConfig } = await import(configPath);

describe("Check development and preview server settings at vite.config.js", () => {
  it("ensure that you have set the development server port to 8080, host to true, and allowedHosts to specified url in vite.config.js", async () => {
    
    expect(viteConfig.server).toBeDefined();
    expect(viteConfig.server.port).toBe(8080);
    expect(viteConfig.server.host).toBe(true);
    
    expect(viteConfig.server.allowedHosts).toBeDefined();
    expect(Array.isArray(viteConfig.server.allowedHosts)).toBe(true);
    expect(viteConfig.server.allowedHosts.length).toBe(1);
    expect(viteConfig.server.allowedHosts[0]).toContain('--8080.pluralsight.run');
  });

  it("ensure that you have set the preview server port to 8080, host to true, and allowedHosts to specified url in vite.config.js", () => {
    expect(viteConfig.preview).toBeDefined();
    expect(viteConfig.preview.port).toBe(8080);
    expect(viteConfig.preview.host).toBe(true);
    
    expect(viteConfig.preview.allowedHosts).toBeDefined();
    expect(Array.isArray(viteConfig.preview.allowedHosts)).toBe(true);
    expect(viteConfig.preview.allowedHosts.length).toBe(1);
    expect(viteConfig.preview.allowedHosts[0]).toContain('--8080.pluralsight.run');
  });
});
