import { describe, it, expect } from 'vitest'
import { readFileSync, existsSync } from 'fs'
import path from 'path'
import { parse } from '@babel/parser'

describe('Check the Introduction component image setup', () => {
  
    it('ensure that you have imported pizza-logo.png from "../assets/images/pizza-logo.png" as pizzaLogo in the "src/components/Introduction.jsx" file', () => {
    
    const filePath = path.resolve(process.cwd(), 'src/components/Introduction.jsx')
    expect(existsSync(filePath)).toBe(true)
    const code = readFileSync(filePath, 'utf8')
    const ast = parse(code, { sourceType: 'module', plugins: ['jsx'] })

    const importDecl = ast.program.body.find(node =>
      node.type === 'ImportDeclaration' &&
      typeof node.source.value === 'string' &&
      node.source.value.includes('/assets/images/pizza-logo.png') &&
      node.specifiers.some(spec => spec.local.name === 'pizzaLogo')
    )
    expect(importDecl).toBeDefined()

  })

  it('ensure that you have used the imported pizzaLogo variable as the src attribute of an img element in the "src/components/Introduction.jsx" file', () => {
    
    const filePath = path.resolve(process.cwd(), 'src/components/Introduction.jsx')
    expect(existsSync(filePath)).toBe(true)
    const code = readFileSync(filePath, 'utf8')
    const ast = parse(code, { sourceType: 'module', plugins: ['jsx'] })

    let usedPizzaLogo = false
    const traverse = node => {
      if (node.type === 'JSXElement' && node.openingElement.name.name === 'img') {
        const srcAttr = node.openingElement.attributes.find(attr =>
          attr.type === 'JSXAttribute' &&
          attr.name.name === 'src' &&
          attr.value.type === 'JSXExpressionContainer' &&
          attr.value.expression.type === 'Identifier' &&
          attr.value.expression.name === 'pizzaLogo'
        )
        if (srcAttr) usedPizzaLogo = true
      }
      for (const key in node) {
        const child = node[key]
        if (Array.isArray(child)) child.forEach(traverse)
        else if (child && typeof child === 'object') traverse(child)
      }
    }

    traverse(ast.program)
    expect(usedPizzaLogo).toBe(true)

  })
  
})