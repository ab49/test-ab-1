import { describe, it, expect } from 'vitest'
import { readFileSync, existsSync } from 'fs'
import path from 'path'
import { parse } from '@babel/parser'

describe('Check the AppPower component image source', () => {
  
  it('ensure that you have added "/react.svg" as the src attribute of the img element in the src/components/AppPower.jsx file', () => {
   
    const filePath = path.resolve(process.cwd(), 'src/components/AppPower.jsx')
    expect(existsSync(filePath)).toBe(true)
    const code = readFileSync(filePath, 'utf8')
    const ast = parse(code, { sourceType: 'module', plugins: ['jsx'] })

    let foundImgSrc = false
    const traverse = node => {
      if (node.type === 'JSXElement' && node.openingElement.name.name === 'img') {
        const srcAttr = node.openingElement.attributes.find(
          attr => attr.type === 'JSXAttribute' &&
                  attr.name.name === 'src' &&
                  attr.value.type === 'StringLiteral' &&
                  attr.value.value === '/react.svg'
        )
        if (srcAttr) foundImgSrc = true
      }
      for (const key in node) {
        const child = node[key]
        if (Array.isArray(child)) child.forEach(traverse)
        else if (child && typeof child === 'object') traverse(child)
      }
    }

    traverse(ast.program)
    expect(foundImgSrc).toBe(true)
    
  })
})