import { describe, it, expect } from 'vitest'
import { readFileSync, existsSync } from 'fs'
import path from 'path'
import { parse } from '@babel/parser'

describe('Check that the Introduction component has pizza company name from the environment variable', () => {
  
  it('ensure that you have replaced the hardcoded "Pizza shop" text in the h2 element with import.meta.env.VITE_APP_NAME in the "src/components/Introduction.jsx" file', () => {
    
    const filePath = path.resolve(process.cwd(), 'src/components/Introduction.jsx')
    expect(existsSync(filePath)).toBe(true)
    const code = readFileSync(filePath, 'utf8')
    const ast = parse(code, { sourceType: 'module', plugins: ['jsx', 'importMeta'] })

    let usesEnvVar = false
    const traverse = node => {
      if (
        node.type === 'MemberExpression' &&
        node.property.type === 'Identifier' &&
        node.property.name === 'VITE_APP_NAME' &&
        node.object.type === 'MemberExpression' &&
        node.object.property.type === 'Identifier' &&
        node.object.property.name === 'env' &&
        node.object.object.type === 'MetaProperty' &&
        node.object.object.meta.name === 'import' &&
        node.object.object.property.name === 'meta'
      ) {
        usesEnvVar = true
      }
      for (const key in node) {
        const child = node[key]
        if (Array.isArray(child)) child.forEach(traverse)
        else if (child && typeof child === 'object') traverse(child)
      }
    }
    traverse(ast)
    expect(usesEnvVar).toBe(true)
    
  })
})
