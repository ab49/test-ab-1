import { describe, it, expect } from "vitest";
import { readFileSync, existsSync } from "fs";
import path from "path";
import { parse } from "@babel/parser";

describe("Check the DevPanel environment variables setup", () => {
  
  it("ensure that you have set isDev to import.meta.env.DEV, mode to import.meta.env.MODE, and baseUrl to import.meta.env.BASE_URL in src/components/DevPanel.jsx", () => {
    
    const filePath = path.resolve(process.cwd(), "src/components/DevPanel.jsx");
    expect(existsSync(filePath)).toBe(true);

    const content = readFileSync(filePath, "utf8");
    const ast = parse(content, {
      sourceType: "module",
      plugins: ["jsx", "importMeta"],
    });

    let isDevCorrect = false;
    let modeCorrect = false;
    let baseUrlCorrect = false;

    const traverse = (node) => {
      if (node.type === "VariableDeclarator" && node.id.type === "Identifier") {
      
        if (
          node.id.name === "isDev" &&
          node.init?.type === "MemberExpression" &&
          node.init?.object?.object?.meta?.name === "import" &&
          node.init?.object?.object?.property?.name === "meta" &&
          node.init?.object?.property?.name === "env" &&
          node.init?.property?.name === "DEV"
        ) {
          isDevCorrect = true;
        }

        if (
          node.id.name === "mode" &&
          node.init?.type === "MemberExpression" &&
          node.init?.object?.object?.meta?.name === "import" &&
          node.init?.object?.object?.property?.name === "meta" &&
          node.init?.object?.property?.name === "env" &&
          node.init?.property?.name === "MODE"
        ) {
          modeCorrect = true;
        }

        if (
          node.id.name === "baseUrl" &&
          node.init?.type === "MemberExpression" &&
          node.init?.object?.object?.meta?.name === "import" &&
          node.init?.object?.object?.property?.name === "meta" &&
          node.init?.object?.property?.name === "env" &&
          node.init.property.name === "BASE_URL"
        ) {
          baseUrlCorrect = true;
        }

      }

      for (const key in node) {
        const child = node[key];
        if (Array.isArray(child)) child.forEach(traverse);
        else if (child && typeof child === "object") traverse(child);
      }
      
    };

    traverse(ast.program);

    expect(isDevCorrect).toBe(true);
    expect(modeCorrect).toBe(true);
    expect(baseUrlCorrect).toBe(true);
  });
});
