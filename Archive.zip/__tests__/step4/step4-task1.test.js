import { describe, it, expect } from 'vitest'
import dotenv from 'dotenv'
import { resolve } from 'path'

describe('.env configuration check for VITE_APP_NAME variable', () => {

  it('ensure that you have added VITE_APP_NAME variable with the value of "Awesome Pizza Shop" in the ".env" file', () => {

    const result = dotenv.config({ path: resolve(process.cwd(), '.env') })
    expect(result.error).toBeUndefined()
    
    expect(process.env.VITE_APP_NAME).toBe('Awesome Pizza Shop')

  })
})