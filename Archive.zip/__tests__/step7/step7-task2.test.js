import { describe, it, expect } from 'vitest'
import { existsSync, readFileSync } from 'fs'
import path from 'path'

describe('Check the Production build setup', () => {
  it('ensure that you have defined a "build" script in package.json that runs the Vite build command', () => {
    const pkgPath = path.resolve(process.cwd(), 'package.json')
    expect(existsSync(pkgPath)).toBe(true)
    const pkg = JSON.parse(readFileSync(pkgPath, 'utf8'))
    expect(pkg.scripts).toBeDefined()
    expect(pkg.scripts.build).toMatch(/vite build/)
  })

  it('ensure that you have generated a "dist" directory after running npm run build', () => {
    const distPath = path.resolve(process.cwd(), 'dist')
    expect(existsSync(distPath)).toBe(true)
    const indexPath = path.resolve(distPath, 'index.html')
    expect(existsSync(indexPath)).toBe(true)
  })

})