import { describe, it, expect } from 'vitest'
import { readFileSync, existsSync } from 'fs'
import path from 'path'
import dotenv from 'dotenv'

describe('Check the ".env.production" configuration', () => {
  it('ensure that you have defined VITE_APP_NAME="Super Awesome Pizza Shop" in the ".env.production" file', () => {
    const envPath = path.resolve(process.cwd(), '.env.production')
    expect(existsSync(envPath)).toBe(true)
    const content = readFileSync(envPath, 'utf8')
    expect(content).toMatch(/^VITE_APP_NAME\s*=\s*["']Super Awesome Pizza Shop["']$/m)
  })

  it('ensure that you have parsed ".env.production" and extracted VITE_APP_NAME as "Super Awesome Pizza Shop" using dotenv.parse', () => {
    const envPath = path.resolve(process.cwd(), '.env.production')
    const parsed = dotenv.parse(readFileSync(envPath, 'utf8'))
    expect(parsed.VITE_APP_NAME).toBe('Super Awesome Pizza Shop')
  })
})
