import { describe, it, expect } from 'vitest'
import { readFileSync, existsSync } from 'fs'
import path from 'path'
import postcss from 'postcss'
import { parse } from '@babel/parser'

describe('Check the Introduction CSS module and component integration', () => {
  it('ensure that you have created a .introPara CSS rule setting the color to #888888 by checking the "introduction.module.css" file', () => {
    
    const cssPath = path.resolve(process.cwd(), 'src/assets/css/introduction.module.css')
    expect(existsSync(cssPath)).toBe(true)

    const cssContent = readFileSync(cssPath, 'utf8')
    const root = postcss.parse(cssContent)

    const rule = root.nodes.find(node => node.type === 'rule' && node.selector === '.introPara')
    expect(rule).toBeDefined()

    const decl = rule.nodes.find(node => node.prop === 'color' && node.value === '#888888')
    expect(decl).toBeDefined()

  })

  it('ensure that you have imported the CSS module in the "src/components/Introduction.jsx" file as styles and used styles.introPara', () => {

    const jsxPath = path.resolve(process.cwd(), 'src/components/Introduction.jsx')
    expect(existsSync(jsxPath)).toBe(true)
    const jsxContent = readFileSync(jsxPath, 'utf8')
    const ast = parse(jsxContent, { sourceType: 'module', plugins: ['jsx'] })

    const hasImport = ast.program.body.some(node =>
      node.type === 'ImportDeclaration' &&
      typeof node.source.value === 'string' &&
      node.source.value.includes('/assets/css/introduction.module.css') &&
      node.specifiers.some(spec => spec.local.name === 'styles')
    )
    expect(hasImport).toBe(true)

    let usedIntroPara = false
    const traverse = node => {
      if (node.type === 'MemberExpression' &&
          node.object.name === 'styles' &&
          node.property.name === 'introPara') {
        usedIntroPara = true
      }
      for (const key in node) {
        const child = node[key]
        if (Array.isArray(child)) child.forEach(traverse)
        else if (child && typeof child === 'object') traverse(child)
      }
    }
    traverse(ast.program)
    expect(usedIntroPara).toBe(true)

  })
})
