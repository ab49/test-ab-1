import { describe, it, expect } from 'vitest'
import { readFileSync, existsSync } from 'fs'
import path from 'path'
import { parse } from '@babel/parser'
import postcss from 'postcss'

describe('Check App CSS and import configuration', () => {
  it('ensure that you have imported "./App.css" in the src/App.jsx file', () => {
    
    const jsxPath = path.resolve(process.cwd(), 'src/App.jsx')
    expect(existsSync(jsxPath)).toBe(true)

    const jsxContent = readFileSync(jsxPath, 'utf8')
    const ast = parse(jsxContent, { sourceType: 'module', plugins: ['jsx'] })

    const imports = ast.program.body.filter(
      node => node.type === 'ImportDeclaration' && typeof node.source.value === 'string' && node.source.value.includes('/App.css')
    )
    expect(imports.length).toBeGreaterThan(0)

  })

  it('ensure that you have added a CSS rule in the "src/App.css" file to set the h2 color to #b91c1c', () => {
    
    const cssPath = path.resolve(process.cwd(), 'src/App.css')
    expect(existsSync(cssPath)).toBe(true)

    const cssContent = readFileSync(cssPath, 'utf8')
    const root = postcss.parse(cssContent)
    
    const h2Rule = root.nodes.find(
      node => node.type === 'rule' && node.selector === 'h2'
    )
    expect(h2Rule).toBeDefined()

    const colorDecl = h2Rule.nodes.find(
      decl => decl.prop === 'color' && decl.value === '#b91c1c'
    )
    expect(colorDecl).toBeDefined()

  })
})