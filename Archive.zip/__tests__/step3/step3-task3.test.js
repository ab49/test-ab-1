import { describe, it, expect } from 'vitest'
import { readFileSync, existsSync } from 'fs'
import path from 'path'
import postcss from 'postcss'
import scss from 'postcss-scss'
import { parse } from '@babel/parser'

describe('Check App SCSS configuration', () => {
  
    it('ensure that you have created a $light-background-color variable set to #fff1f2 and a .background-light-red rule using that variable in the "src/assets/css/app-style.scss" file', () => {
    
    const scssPath = path.resolve(process.cwd(), 'src/assets/css/app-style.scss')
    expect(existsSync(scssPath)).toBe(true)

    const scssContent = readFileSync(scssPath, 'utf8')
    const root = postcss.parse(scssContent, { syntax: scss })
    
    const varDecl = root.nodes.find(node => node.type === 'decl' && node.prop === '$light-background-color' && node.value === '#fff1f2')
    expect(varDecl).toBeDefined()

    const rule = root.nodes.find(node => node.type === 'rule' && node.selector === '.background-light-red')
    expect(rule).toBeDefined()

    const bgDecl = rule.nodes.find(node => typeof node.prop === 'string' && (node.prop === 'background' || node.prop === 'background-color') && node.value === '$light-background-color')
    expect(bgDecl).toBeDefined()

  })

  it('ensure that you have imported the SCSS file in the "src/App.jsx" file by importing "./assets/css/app-style.scss" file', () => {
    
    const jsxPath = path.resolve(process.cwd(), 'src/App.jsx')
    expect(existsSync(jsxPath)).toBe(true)
    
    const jsxContent = readFileSync(jsxPath, 'utf8')
    const ast = parse(jsxContent, { sourceType: 'module', plugins: ['jsx'] })

    const hasImport = ast.program.body.some(node =>
      node.type === 'ImportDeclaration' &&
      typeof node.source.value === 'string' &&
      node.source.value.includes('/assets/css/app-style.scss')
    )
    expect(hasImport).toBe(true)

  })
})