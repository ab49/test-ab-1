import { describe, it, expect } from 'vitest'
import { readFileSync, existsSync } from 'fs'
import path from 'path'
import { parse } from '@babel/parser'

describe('Check Introduction component JSON data integration', () => {
  
    it('ensure that you have imported companyInfo from "../assets/data/companyInfo.json" at the top of "src/components/Introduction.jsx" file', () => {

    const filePath = path.resolve(process.cwd(), 'src/components/Introduction.jsx')
    expect(existsSync(filePath)).toBe(true)

    const code = readFileSync(filePath, 'utf8')
    const ast = parse(code, { sourceType: 'module', plugins: ['jsx'] })
    const importDecl = ast.program.body.find(node =>
      node.type === 'ImportDeclaration' &&
      node.source.value === '../assets/data/companyInfo.json' &&
      node.specifiers.some(spec => spec.local.name === 'companyInfo')
    )
    expect(importDecl).toBeDefined()

  })

  it('ensure that you have replaced the hardcoded start date and owner in the <p id="start-info"> element with companyInfo.startDate and companyInfo.owner using JSX expressions', () => {
    
    const filePath = path.resolve(process.cwd(), 'src/components/Introduction.jsx')
    expect(existsSync(filePath)).toBe(true)

    const code = readFileSync(filePath, 'utf8')
    const ast = parse(code, { sourceType: 'module', plugins: ['jsx'] })

    let hasPara = false
    let usedStartDate = false
    let usedOwner = false

    const traverse = node => {
      if (node.type === 'JSXElement' && node.openingElement.name.name === 'p') {
        const hasId = node.openingElement.attributes.some(attr =>
          attr.type === 'JSXAttribute' &&
          attr.name.name === 'id' &&
          attr.value.type === 'StringLiteral' &&
          attr.value.value === 'start-info'
        )
        if (hasId) hasPara = true
      }

      if (
        node.type === 'JSXExpressionContainer' &&
        node.expression.type === 'MemberExpression' &&
        node.expression.object.name === 'companyInfo'
      ) {
        if (node.expression.property.name === 'startDate') usedStartDate = true
        if (node.expression.property.name === 'owner') usedOwner = true
      }

      for (const key in node) {
        const child = node[key]
        if (Array.isArray(child)) child.forEach(traverse)
        else if (child && typeof child === 'object') traverse(child)
      }
    }

    traverse(ast.program)

    expect(hasPara).toBe(true)
    expect(usedStartDate).toBe(true)
    expect(usedOwner).toBe(true)
    
  })
  
})