import { describe, it, expect } from 'vitest'
import { existsSync, readFileSync } from 'fs'
import path from 'path'
import { parse } from '@babel/parser'
import traverse from '@babel/traverse'

describe('Check glob import of testimonial modules in "src/components/Testimonials.jsx"', () => {
  it('ensure that you have used Vites "import.meta.glob" call with "{ eager: true }" in the "src/components/Testimonials.jsx" to load all JSON files from the "assets/testimonial" folder', () => {
    const filePath = path.resolve(process.cwd(), 'src/components/Testimonials.jsx')
    expect(existsSync(filePath)).toBe(true)

    const code = readFileSync(filePath, 'utf8')
    const ast = parse(code, {
      sourceType: 'module',
      plugins: ['jsx']
    })

    let found = false
    traverse(ast, {
      CallExpression(path) {
        const { callee, arguments: args } = path.node
        // Check for import.meta.glob call
        if (
          callee.type === 'MemberExpression' &&
          callee.object.type === 'MetaProperty' &&
          callee.object.meta.name === 'import' &&
          callee.object.property.name === 'meta' &&
          callee.property.name === 'glob' &&
          args.length === 2 &&
          args[0].type === 'StringLiteral' &&
          typeof args[0].value === 'string' &&
          args[0].value.includes('/assets/testimonial/*.json') &&
          args[1].type === 'ObjectExpression' &&
          args[1].properties.some(prop =>
            prop.key.name === 'eager' &&
            prop.value.type === 'BooleanLiteral' &&
            prop.value.value === true
          )
        ) {
          found = true
        }
      }
    })

    expect(found).toBe(true)
  })
})
