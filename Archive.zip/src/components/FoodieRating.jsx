import React, { useState } from 'react';

const FoodieRating = () => {
  
  const [name, setName] = useState('');
  const [rating, setRating] = useState(5);
  
  const isProd = import.meta.env.PROD

  if(isProd){
    return;
  }

  const incrementRating = () => {
    if (rating < 10) setRating(rating + 1);
  };

  const decrementRating = () => {
    if (rating > 1) setRating(rating - 1);
  };

  return (
    <section className="foodie-rating background-light-red p-8 rounded-lg shadow-md max-w-md mx-auto my-8">
      <h2 className="text-2xl font-bold text-center text-red-700 mb-4 border-b pb-2">Foodie Rating</h2>
      <div className="rating-form space-y-4">
        <label className="block text-gray-700">
          <span className="font-medium">Your Name:</span>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Enter your name"
            className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-red-300"
          />
        </label>
        <div className="rating-controls flex items-center justify-center space-x-4">
          <button 
            onClick={decrementRating} 
            className="bg-red-200 hover:bg-red-300 text-red-800 font-bold py-2 px-4 rounded transition duration-300"
          >
            -
          </button>
          <span className="text-xl font-semibold text-gray-800">{rating}</span>
          <button 
            onClick={incrementRating} 
            className="bg-red-200 hover:bg-red-300 text-red-800 font-bold py-2 px-4 rounded transition duration-300"
          >
            +
          </button>
        </div>
        {name && (
          <p className="text-center text-gray-700 font-medium">
            {name}, you rated us {rating} out of 10!
          </p>
        )}
      </div>
    </section>
  );
}

export default FoodieRating;
