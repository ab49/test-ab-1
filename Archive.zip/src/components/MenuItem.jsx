import React, { useState } from 'react';

const MenuItem = ({ item }) => {
  const [quantity, setQuantity] = useState(0);

  const handleIncrement = () => {
    setQuantity(quantity + 1);
  };

  const handleDecrement = () => {
    if (quantity > 0) setQuantity(quantity - 1);
  };

  return (
    <div className="menu-item bg-white border border-gray-300 rounded-lg shadow p-6 flex flex-col items-center text-center">
      <img
        src={item.image}
        alt={item.name}
        className="menu-item-image w-full h-48 object-cover rounded-md mb-4"
      />
      <h3 className="text-xl font-bold text-red-700 mb-2">{item.name}</h3>
      <p className="text-lg font-semibold text-gray-800 mb-1">Price: ${item.price}</p>
      <p className="text-gray-600 mb-4">Ingredients: {item.ingredients.join(', ')}</p>
      <div className="quantity-controls flex items-center justify-center mb-4">
        <button
          onClick={handleDecrement}
          className="bg-red-200 hover:bg-red-300 text-red-800 font-bold py-1 px-3 rounded-l transition duration-300"
        >
          -
        </button>
        <span className="px-4 py-1 border-t border-b border-red-200">{quantity}</span>
        <button
          onClick={handleIncrement}
          className="bg-red-200 hover:bg-red-300 text-red-800 font-bold py-1 px-3 rounded-r transition duration-300"
        >
          +
        </button>
      </div>
      <button
        disabled
        className="bg-gray-200 text-gray-500 px-4 py-2 rounded cursor-not-allowed hover:opacity-80 transition duration-300"
      >
        Add to Cart
      </button>
    </div>
  );
};

export default MenuItem;
