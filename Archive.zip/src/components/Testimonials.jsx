import React from 'react';

// glob import all JSON testimonial files from the assets/testimonial folder
const testimonialsModules = {};
const testimonials = Object.values(testimonialsModules);

const Testimonials = () => {
  // Helper function to render stars based on the rating (out of 5)
  const renderStars = (rating) => {
    return Array(5)
      .fill(null)
      .map((_, index) => (
        <span key={index} className="text-yellow-500 text-xl">
          {index < rating ? '★' : '☆'}
        </span>
      ));
  };

  return (
    <section className="testimonials background-light-red border border-gray-300 p-6 rounded-xl shadow-md max-w-3xl mx-auto my-8">
      <h2 className="text-3xl font-bold text-center text-red-600 mb-6 border-b pb-2">Testimonials</h2>
      <div className="testimonial-list space-y-4">
        {testimonials.map((testimonial, index) => (
          <div key={index} className="testimonial-item bg-gray-50 p-4 rounded-lg border border-red-200 shadow-sm">
            <p className="testimonial-text text-gray-800">"{testimonial.text}"</p>
            <p className="testimonial-author mt-2 font-medium text-gray-700">- {testimonial.author}</p>
            <div className="testimonial-rating mt-2">
              {renderStars(testimonial.rating)}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Testimonials;
