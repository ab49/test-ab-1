import { disclaimer } from '../assets/data/legal.json'

const Disclaimer = () => (
    <section className="bg-yellow-100 border border-yellow-300 text-yellow-800 p-4 rounded-lg text-sm max-w-3xl mx-auto mt-8 shadow">
        <p><strong>Disclaimer:</strong> {disclaimer}</p>
    </section>
);

export default Disclaimer;
