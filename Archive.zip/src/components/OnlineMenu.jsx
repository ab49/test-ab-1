import React from 'react';
import MenuItem from './MenuItem';
import menuData from '../assets/menu/online-menu.json';

const OnlineMenu = () => {
  return (
    <section className="background-light-red online-menu p-8 rounded-lg shadow-md max-w-7xl mx-auto my-8">
      <h2 className="text-3xl font-bold text-center text-red-700 mb-8">Our Online Menu</h2>
      <div className="menu-list grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
        {menuData.map((item, index) => (
          <MenuItem key={index} item={item} />
        ))}
      </div>
    </section>
  );
};

export default OnlineMenu;
